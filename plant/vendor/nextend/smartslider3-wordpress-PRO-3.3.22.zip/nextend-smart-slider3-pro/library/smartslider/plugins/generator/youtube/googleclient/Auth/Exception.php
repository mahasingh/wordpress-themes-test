<?php

namespace Nextend\GoogleApi;

class Google_Auth_Exception extends Google_Exception {

}
