import SmartSlider3 from './SmartSlider3/SmartSlider3';
import SmartSlider3FullWidth from './SmartSlider3FullWidth/SmartSlider3FullWidth';

export default [SmartSlider3, SmartSlider3FullWidth];