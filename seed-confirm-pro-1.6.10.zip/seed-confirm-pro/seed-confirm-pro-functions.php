<?php

/**
 * Check woo-commerce plugin is installed and activated or not.
 * @return bool
 */
if (! function_exists('is_woo_activated')) {
    function is_woo_activated()
    {
        if (class_exists('woocommerce')) {
            return true;
        } else {
            return false;
        }
    }
}

/**
 * Get array of banks.
 * @param array $accounts
 * @return array
 */
if (!function_exists('seed_confirm_get_banks')) {
    function seed_confirm_get_banks($accounts)
    {
        $accounts_with_logos = array();

        if (!empty($accounts) && is_array($accounts) && count($accounts) > 0) {
            foreach ($accounts as $_account) {
                $logo = '';
                $bank_name = trim($_account['bank_name']);

                if ((false !==  mb_strpos($bank_name, 'กสิกร'))
                    || false !== mb_strpos($bank_name, '开泰银行')
                    || false !== stripos($bank_name, 'kbank')
                    || false !== stripos($bank_name, 'kasikorn')) {
                    $logo = 'kbank';
                } elseif ((false !== mb_strpos($bank_name, 'กรุงเทพ'))
                    || false !== mb_strpos($bank_name, '盘古银行')
                    || false !== stripos($bank_name, 'bbl')
                    || false !== stripos($bank_name, 'bangkok')
                    || false !== stripos($bank_name, 'bualuang')) {
                    $logo = 'bbl';
                } elseif ((false !== mb_strpos($bank_name, 'กรุงไทย'))
                    || false !== mb_strpos($bank_name, '泰京银行')
                    || false !== stripos($bank_name, 'ktb')
                    || false !== stripos($bank_name, 'krungthai')) {
                    $logo = 'ktb';
                } elseif ((false !== mb_strpos($bank_name, 'ทหารไทย'))
                    || false !== mb_strpos($bank_name, '泰国军人银行')
                    || false !== stripos($bank_name, 'tmb')
                    || false !== stripos($bank_name, 'thai military')) {
                    $logo = 'tmb';
                } elseif ((false !== mb_strpos($bank_name, 'ไทยพาณิชย์'))
                    || false !== mb_strpos($bank_name, '汇商银行')
                    || false !== stripos($bank_name, 'scb')
                    || false !== stripos($bank_name, 'siam commercial')) {
                    $logo = 'scb';
                } elseif ((false !== mb_strpos($bank_name, 'กรุงศรี'))
                    || false !== mb_strpos($bank_name, '大城银行')
                    || false !== stripos($bank_name, 'bay')
                    || false !== stripos($bank_name, 'krungsri')) {
                    $logo = 'krungsri';
                } elseif ((false !== mb_strpos($bank_name, 'ซิดี้'))
                    || false !== stripos($bank_name, 'citi')) {
                    $logo = 'citi';
                } elseif ((false !== mb_strpos($bank_name, 'ออมสิน'))
                    || false !== mb_strpos($bank_name, '政府储蓄银行')
                    || false !== stripos($bank_name, 'gsb')) {
                    $logo = 'gsb';
                } elseif ((false !== mb_strpos($bank_name, 'ธนชาต'))
                    || false !== mb_strpos($bank_name, '泰纳昌银行')
                    || false !== stripos($bank_name, 'tbank')) {
                    $logo = 'tbank';
                } elseif ((false !== mb_strpos($bank_name, 'ยูโอบี'))
                || false !== mb_strpos($bank_name, '大华银行')
                    || false !== stripos($bank_name, 'uob')) { 
                    $logo = 'uob';
                } elseif ((false !== mb_strpos($bank_name, 'อิสลาม'))
                    || false !== stripos($bank_name, 'islamic')
                    || false !== stripos($bank_name, 'ibank')) {
                    $logo = 'ibank';
                } elseif ((false !== mb_strpos($bank_name, 'อาคารสงเคราะห์'))
                    || false !== mb_strpos($bank_name, '住宅银行')
                    || false !== mb_strpos($bank_name, 'ธอส')
                    || false !== stripos($bank_name, 'ghb')) {
                    $logo = 'ghb';
                } elseif ((false !== mb_strpos($bank_name, 'เพื่อการเกษตร'))
                    || false !== mb_strpos($bank_name, '农业合作银行')
                    || false !== mb_strpos($bank_name, 'ธ.ก.ส.')
                    || false !== mb_strpos($bank_name, 'ธกส')
                    || false !== stripos($bank_name, 'baac')) {
                    $logo = 'baac';
                } elseif ((false !== mb_strpos($bank_name, 'ทิสโก้'))
                    || false !== mb_strpos($bank_name, '铁士古银行')
                    || false !== stripos($bank_name, 'tisco')) {
                    $logo = 'tisco';
                }elseif ((false !== mb_strpos($bank_name, 'เกียรตินาคิน'))
                    || false !== mb_strpos($bank_name, '甲那金银行')
                    || false !== stripos($bank_name, 'kiatnakin')
                    || false !== stripos($bank_name, 'kkp')) {
                    $logo = 'kkp';
                } elseif ((false !== mb_strpos($bank_name, 'ไอซีบีซี'))
                    || false !== mb_strpos($bank_name, '工商银行')
                    || false !== stripos($bank_name, 'icbc')) {
                    $logo = 'icbc';
                } elseif ((false !== mb_strpos($bank_name, 'แห่งประเทศจีน'))
                    || false !== mb_strpos($bank_name, '中国银行')
                    || false !== stripos($bank_name, 'bank of china')
                    || false !== stripos($bank_name, 'boc')) {
                    $logo = 'boc';
                } elseif ((false !== mb_strpos($bank_name, 'พร้อมเพย์'))
                    || false !== stripos($bank_name, 'promptpay')) {
                    $logo = 'promptpay';
                } elseif (false !== stripos($bank_name, 'bca')) { /* ------------- ID BANKS ------------- */
                    $logo = 'bca';
                } elseif (false !== stripos($bank_name, 'bni')) {
                    $logo = 'bni';
                } elseif (false !== stripos($bank_name, 'bri')) {
                    $logo = 'bri';
                } elseif (false !== stripos($bank_name, 'mandiri')) {
                    $logo = 'mandiri';
                } elseif (false !== stripos($bank_name, 'btpn')) {
                    $logo = 'btpn';
                }  elseif ((false !== mb_strpos($bank_name, 'การค้าต่างประเทศลาว'))
                    || false !== mb_strpos($bank_name, 'ການຄ້າຕ່າງປະເທດລາວ')
                    || false !== stripos($bank_name, 'bcel')) { /* ------------- LOAS BANKS ------------- */
                    $logo = 'bcel';
                }

                if ($logo !== '') {
                    $_account['logo'] = plugins_url('img/'.$logo.'.png', __FILE__);
                } else {
                    $_account['logo'] = plugins_url('img/none.png', __FILE__);
                }

                $accounts_with_logos[] = $_account;
            }
        }

        return $accounts_with_logos;
    }
}

/**
 * Use for generate unique file name.
 * Difficult to predict.
 * Only slip image that upload through seed-confirm.
 * @param $dir
 * @param $name
 * @param $ext
 * @return (string) uniq name
 */
if (!function_exists('seed_unique_filename')) {
    function seed_unique_filename($dir, $name, $ext)
    {
        return 'slip-'.md5($dir.$name.time()).$ext;
    }
}


/**
 * Find Order ID from Order Number
 */

if (!function_exists('seed_get_order_id')) {
    function seed_get_order_id($order_number)
    {   
        $order_id = $order_number;
        if (!class_exists('woocommerce')) {
            return $order_id;
        }
        // Check for https://woocommerce.com/products/sequential-order-numbers-pro/
        if ( function_exists( 'wc_seq_order_number_pro' ) ) {
            $order_id = wc_seq_order_number_pro()->find_order_by_order_number($order_number);
            return $order_id;
        } else {
            // Other Plugins including https://wordpress.org/plugins/custom-order-numbers-for-woocommerce/
            $orders = wc_get_orders(array( 
                'limit' => 800, 
                'orderby' => 'date', 
                'order' => 'DESC',
                'post_status' => array('wc-on-hold', 'wc-processing', 'wc-checking-payment')
            ));
            foreach ($orders as $order) {
                if ($order->get_order_number() == $order_number) {
                    $order_id = $order->get_id();
                    break;
                } 
            }
            if (is_int($order_id)) {
                return $order_id;
            } else {
                return false;
            }
        }
    }
}